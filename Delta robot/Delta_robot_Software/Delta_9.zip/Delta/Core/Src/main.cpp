/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <string.h>
#include "Math.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
class Vector3
{
public:
  // these usions allow the Vector3 to be used as a color component
  float x;
  float y;
  float z;

public:
  Vector3() {}


  Vector3( float xx, float yy, float zz )
  {
    x = xx;
    y = yy;
    z = zz;
  }


  Vector3( float v[ 3 ] )
  {
    x = v[ 0 ];
    y = v[ 1 ];
    z = v[ 2 ];
  }


  ~Vector3() {};


  Vector3 &MakeZero() {
    x=0;
    y=0;
    z=0;

    return *this;
  }


  Vector3 &Set( float xx, float yy, float zz ) {
    x = xx;
    y = yy;
    z = zz;

    return *this;
  }


  Vector3 operator + () const { // Unary negation
    return Vector3(*this);
  }


  Vector3 operator - () const { // Unary negation
    return Vector3( -x, -y, -z );
  }


  Vector3 operator *= ( float v ) { // assigned multiply by a float
    x *= v;
    y *= v;
    z *= v;

    return *this;
  }


  Vector3 operator /= ( float t ) { // assigned division by a float
    float v;

    if( t == 0.0f )
      v = 0;
    else
      v = 1.0f / t;

    x *= v;
    y *= v;
    z *= v;

    return *this;
  }


  Vector3 operator -= ( const Vector3 &v ) { // assigned subtraction
    x -= v.x;
    y -= v.y;
    z -= v.z;

    return *this;
  }


  Vector3 operator += ( const Vector3 &v ) { // assigned addition
    x += v.x;
    y += v.y;
    z += v.z;

    return *this;
  }


  Vector3 operator *= ( const Vector3 &v ) { // assigned mult.
    x *= v.x;
    y *= v.y;
    z *= v.z;

    return *this;
  }


  Vector3 operator ^= ( const Vector3 &v ) { // assigned cross product
    float nx, ny, nz;

    nx = ( y * v.z - z * v.y );
    ny =-( x * v.z - z * v.x );
    nz = ( x * v.y - y * v.x );
    x = nx;
    y = ny;
    z = nz;

    return *this;
  }

/*
  bool operator == ( const Vector3 &v ) const {
    return ( abs( x - v.x ) < 0.01f &&
             abs( y - v.y ) < 0.01f &&
             abs( z - v.z ) < 0.01f );
  }*/

/*
  bool operator != ( const Vector3 &v ) const {
    return ( abs( x - v.x ) > 0.01f ||
             abs( y - v.y ) > 0.01f ||
             abs( z - v.z ) > 0.01f );
  }*/


  // METHODS
  float Length() const {
    return (float)sqrt( x*x+y*y+z*z );
  }


  float LengthSquared() const {
    return x*x+y*y+z*z;
  }


  void Normalize() {
    float len, iLen;

    len = Length();
    if( !len ) iLen = 0;
    else iLen = 1.0f / len;

    x *= iLen;
    y *= iLen;
    z *= iLen;
  }


  float NormalizeLength() {
    float len, iLen;

    len = Length();
    if( !len ) iLen = 0;
    else iLen = 1.0f / len;

    x *= iLen;
    y *= iLen;
    z *= iLen;

    return len;
  }


  void ClampMin( float min ) { // Clamp to minimum
    if( x < min ) x = min;
    if( y < min ) y = min;
    if( z < min ) z = min;
  }


  void ClampMax( float max ) { // Clamp to maximum
    if( x > max ) x = max;
    if( y > max ) y = max;
    if( z > max ) z = max;
  }


  void Clamp( float min, float max ) { // Clamp to range ]min,max[
    ClampMin( min );
    ClampMax( max );
  }


  // Interpolate between *this and v
  void Interpolate( const Vector3 &v, float a ) {
    float b( 1.0f - a );

    x = b * x + a * v.x;
    y = b * y + a * v.y;
    z = b * z + a * v.z;
  }


  float operator | ( const Vector3 &v ) const { // Dot product
    return x * v.x + y * v.y + z * v.z;
  }


  Vector3 operator / ( float t ) const { // vector / float
    if( t == 0.0f )
      return Vector3( 0, 0, 0 );

    float s( 1.0f / t );

    return Vector3( x * s, y * s, z * s );
  }


  Vector3 operator + ( const Vector3 &b ) const { // vector + vector
    return Vector3( x + b.x, y + b.y, z + b.z );
  }


  Vector3 operator - ( const Vector3 &b ) const { // vector - vector
    return Vector3( x - b.x, y - b.y, z - b.z );
  }


  Vector3 operator * ( const Vector3 &b ) const { // vector * vector
    return Vector3( x * b.x, y * b.y, z * b.z );
  }


  Vector3 operator ^ ( const Vector3 &b ) const { // cross(a,b)
    float nx, ny, nz;

    nx = y * b.z - z * b.y;
    ny = z * b.x - x * b.z;
    nz = x * b.y - y * b.x;

    return Vector3( nx, ny, nz );
  }


  Vector3 operator * ( float s ) const {
    return Vector3( x * s, y * s, z * s );
  }


  void Rotate( Vector3 &axis, float angle ) {
    float sa = (float)sin( angle );
    float ca = (float)cos( angle );
    Vector3 axis2( axis );
    float m[9];

    axis2.Normalize();

    m[ 0 ] = ca + (1 - ca) * axis2.x * axis2.x;
    m[ 1 ] = (1 - ca) * axis2.x * axis2.y - sa * axis2.z;
    m[ 2 ] = (1 - ca) * axis2.z * axis2.x + sa * axis2.y;
    m[ 3 ] = (1 - ca) * axis2.x * axis2.y + sa * axis2.z;
    m[ 4 ] = ca + (1 - ca) * axis2.y * axis2.y;
    m[ 5 ] = (1 - ca) * axis2.y * axis2.z - sa * axis2.x;
    m[ 6 ] = (1 - ca) * axis2.z * axis2.x - sa * axis2.y;
    m[ 7 ] = (1 - ca) * axis2.y * axis2.z + sa * axis2.x;
    m[ 8 ] = ca + (1 - ca) * axis2.z * axis2.z;

    Vector3 src( *this );

    x = m[0] * src.x + m[1] * src.y + m[2] * src.z;
    y = m[3] * src.x + m[4] * src.y + m[5] * src.z;
    z = m[6] * src.x + m[7] * src.y + m[8] * src.z;
  }
};

struct Joint
{
  Vector3 up;
  Vector3 left;
  Vector3 forward;
  Vector3 pos;
  Vector3 relative;
};

struct Arm
{
  Joint shoulder;
  Joint elbow;
  Joint wrist;
  Joint wop;
//  Servo s;  //TIM의  CCR이 들어가야되는 부분
  float a;
  int angle;
};
#define NUM_ARMS (4)

struct DeltaRobot
{
  Arm arms[NUM_ARMS];
  Joint ee;
  Joint base;
  float default_height;
};

struct Shape
{
  int idx;
  int x;
  int y;
};

const double PI = 3.1415926;

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define BOARD

/*
#define MOTORa 3
#define MOTORb 5
#define MOTORc 6
#define MOTORd 9
*/

#define TWOPI            (PI*2.0f)
#define DEG2RAD          (PI/180.0f)
#define RAD2DEG          (180.0f/PI)
#define DELAY            (5) // 5 fix

#define CM_PER_SEGMENT   (0.50) //0.50
#define MIN_FEED_RATE    (0.01)  // cm/s

#define TxBufferSize (countof(TxBuffer) - 1)
#define RxBufferSize 0xFF
#define countof(a) (sizeof(a) / sizeof(*(a)))

#define angleZeroPulse 700
#define CENTERX 15
#define CENTERY 12
#define ZOFFSET1 20
#define ZOFFSET2 27
#define NONE 5

static const float shoulder_to_elbow  = 16.0f;  // cm
static const float elbow_to_wrist     = 20.0f;  // cm

#if NUM_ARMS == 4
static const float center_to_shoulder = 14.35f;  // cm
static const float effector_to_wrist  = 7.5f;  // cm
#endif

#ifdef BOARD
//static const int pins[] = {MOTORa,MOTORb,MOTORc,MOTORd};
#endif

#define PRINTF 1

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim3;
TIM_HandleTypeDef htim4;
TIM_HandleTypeDef htim5;

UART_HandleTypeDef huart3;
UART_HandleTypeDef huart6;

/* USER CODE BEGIN PV */
uint8_t TxBuffer[] = "\n\rUART Example 1 (Transmission Success !!)\n\r\n\r";
uint8_t RxBuffer[RxBufferSize];
char pox=0;
char poy=0;
float pix=0;
float piy=0;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_TIM2_Init(void);
static void MX_TIM3_Init(void);
static void MX_TIM4_Init(void);
static void MX_TIM5_Init(void);
static void MX_USART3_UART_Init(void);
static void MX_USART6_UART_Init(void);
/* USER CODE BEGIN PFP */
//delta
void ik();
void moveArm(int id,float angle);
char outOfBounds(float x,float y,float z);
void setup_robot();
static void line_safe(float x,float y,float z);
void arc(char cw,float cx,float cy,float cz,float x,float y,float z);
void line(float x, float y, float z);
void conclude(void);
//motors
void Motor1(uint16_t angle);
void Motor2(uint16_t angle);
void Motor3(uint16_t angle);
void Motor4(uint16_t angle);
void Spin(uint16_t angle);
//magnetic
void MagneticOn(void);
void MagneticOff(void);
//activity
void PickUp(float x, float y);
void PickDown(float x, float y);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
#if PRINTF ==1
	#ifdef __cplusplus
		extern "C" int _write(int32_t file, uint8_t *ptr, int32_t len) {
	#else
			int _write(int32_t file, uint8_t *ptr, int32_t len) {
	#endif
		if( HAL_UART_Transmit(&huart3, ptr, len, len) == HAL_OK ) return len;
		else return 0;
	}
#endif

#ifdef __GNUC__
	int __io_putchar(int ch)
#else
	int fputc(int ch, FILE *f)
#endif
{
  HAL_UART_Transmit(&huart3, (uint8_t *)&ch, 1, 0xFFFF);
  return ch;
}

long start;  // clock time since start
long last_frame, this_frame;  // for finding dt
double dt;

int sofar;

DeltaRobot robot;
struct Shape shape[5];
float feed_rate=20;  // how fast the tool moves in cm/s

int reverse=0;

int MAX_ANGLE    = 180;
int MIN_ANGLE    = 90;

uint32_t time;
volatile uint32_t counter;

int uartFlag;

float atan3(float dy,float dx)
{
  float a=atan2(dy,dx);
  if(a<0) a=(PI*2.0)+a;
  return a;
}
void setup_robot()
{
  Vector3 temp,n;
  float aa,bb,cc;
  int i;

  for(i=0;i<NUM_ARMS;++i)
  {
    Arm &a=robot.arms[i];
    // shoulder
    a.shoulder.pos=Vector3(cos(TWOPI*i/NUM_ARMS)*center_to_shoulder, sin(TWOPI*i/NUM_ARMS)*center_to_shoulder,0);
    // elbow
    a.elbow.pos=Vector3(cos(TWOPI*i/NUM_ARMS)*(center_to_shoulder+shoulder_to_elbow),sin(TWOPI*i/NUM_ARMS)*(center_to_shoulder+shoulder_to_elbow),0);
    // Find wrist position.  This is a special case of forward kinematics.
    n=a.shoulder.pos;
    n.Normalize();
    temp=a.shoulder.pos-n*(center_to_shoulder-effector_to_wrist);
    aa=(a.elbow.pos-temp).Length();
    cc=elbow_to_wrist;
    bb=sqrt((cc*cc)-(aa*aa));
    a.wrist.pos=temp+Vector3(0,0,bb);

    a.elbow.relative=a.elbow.pos;
    a.wrist.relative=a.wrist.pos;
    a.wrist.relative.z=0;

    // connect to the servos
//    robot.arms[i].s.attach(pins[i]);
    // center the arm
    Motor1(120);
    Motor2(120);
    Motor3(120);
    Motor4(120);

  }
  robot.default_height=bb;
  robot.ee.pos.z=bb;
}
char outOfBounds(float x,float y,float z) {
  // test if the move is impossible
  int error=0;
  int i;
  Vector3 w, test(x,y,z);
  float len;
  for(i=0;i<NUM_ARMS;++i) {
    Arm &arm=robot.arms[i];
    // get wrist position
    w = test + arm.wrist.relative - arm.shoulder.pos;
    len=w.Length() - elbow_to_wrist;

    if(fabs(len) > shoulder_to_elbow)
    {
    	return 1;
    }
  }
  return 0;
}
void moveArm(int id,float angle)
{
  Arm &arm=robot.arms[id];

  if(angle>MAX_ANGLE)
    angle = MAX_ANGLE;
  if(angle<MIN_ANGLE)
    angle = MIN_ANGLE;
  switch(id)
  {
  //default: +10 +0 +5 -8
    case 0:
    //robot.arms[id].a=angle+10;
  	Motor1(angle+10);
    break;
    case 1:
    //robot.arms[id].a=angle+10;
    Motor2(angle);
    break;
    case 2:
    //robot.arms[id].a=angle+5;
    Motor3(angle+5);
    break;
    case 3:
    //robot.arms[id].a=angle;
    Motor4(angle-8);
    break;
   }
}
void ik()
{
  // find wrist positions
  int i;
  for(i=0;i<NUM_ARMS;++i)
  {
    Arm &arm=robot.arms[i];

    // get wrist position
    arm.wrist.pos = robot.ee.pos + arm.wrist.relative;
    Vector3 ortho=arm.shoulder.pos;
    ortho.z=0;
    ortho.Normalize();
    Vector3 norm(-ortho.y,ortho.x,0);
    norm.Normalize();

    // get wrist position on plane of bicep
    Vector3 w = arm.wrist.pos - arm.shoulder.pos;
    float a=w | norm;  // ee' distance
    Vector3 wop = w - norm * a;
    arm.wop.pos=wop + arm.shoulder.pos;

    // use pythagorean theorem to get e'j
    float b=sqrt(elbow_to_wrist*elbow_to_wrist-a*a);

    // use intersection of circles to find elbow point (j).
    //a = (r0r0 - r1r1 + d*d ) / (2 d)
    float r1=b;  // circle 1 centers on e'
    float r0=shoulder_to_elbow;  // circle 0 centers on shoulder
    float d=wop.Length();
    // distance from shoulder to the midpoint between the two possible intersections
    a = ( r0 * r0 - r1 * r1 + d*d ) / ( 2*d );
    // find the midpoint
    Vector3 n2=wop;
    n2.Normalize();
    Vector3 temp=arm.shoulder.pos+(n2*a);
    // with a and r0 we can find h, the distance from midpoint to intersections.
    float h=sqrt(r0*r0-a*a);
    // get a normal to the line wop in the plane orthogonal to ortho
    Vector3 r = norm ^ n2;
    Vector3 p1 = temp + r * h;

    arm.elbow.pos=p1;

    // use atan2 to find theta
    temp=arm.elbow.pos-arm.shoulder.pos;
    float y=temp.z;
    temp.z=0;
    float x=temp.Length();

    if( ( arm.elbow.relative | temp ) < 0 ) x=-x;

    float new_angle=atan2(-y,x) * RAD2DEG;
    // cap the angle
    if(new_angle>90) new_angle=90;
    if(new_angle<-90) new_angle=-90;

    int nx = 90 +  ( (reverse==1) ? new_angle : -new_angle );

    moveArm(i,nx);
  }
}
void line(float x, float y, float z)
{
  if( outOfBounds(x, y, z) )
  {
    return;
  }

  Vector3 destination(x,y,z);
  Vector3 start = robot.ee.pos;  // keep a copy of start for later in this method
  Vector3 dp = destination - start;  // far do we have to go?
  float travel_time = dp.Length() / feed_rate;
  travel_time *= 500; // convert to ms //(delta speed) Basic:1000

  long start_time = time + (uint32_t)TIM5->CNT;
  long time_now = start_time;

  float f;
  while(time_now - start_time < travel_time)
  {

    time_now = time + (uint32_t)TIM5->CNT;

    f = (float)(time_now - start_time) / travel_time;
    robot.ee.pos = dp * f + start;

    //printEEPosition();
    // update the inverse kinematics
    ik();

    HAL_Delay(DELAY);
  }

  // one last time to make sure we hit right on the money
  robot.ee.pos = destination;
  // update the inverse kinematics
  ik();
}
static void line_safe(float x,float y,float z)
{
  // split up long lines to make them straighter?
  float dx=x-robot.ee.pos.x;
  float dy=y-robot.ee.pos.y;

  float len=sqrt(dx*dx+dy*dy);

  if(len<=CM_PER_SEGMENT)
  {
    line(x,y,z);
    return;
  }

  // too long!
  long pieces=ceil(len/CM_PER_SEGMENT);
  float x0=robot.ee.pos.x;
  float y0=robot.ee.pos.y;
  float z0=robot.ee.pos.z;
  float a;
  for(int j=0;j<=pieces;++j)
  {
    a=(float)j/(float)pieces;
    line((x-x0)*a+x0,(y-y0)*a+y0,(z-z0)*a+z0);
  }
}
void arc(char cw,float cx,float cy,float cz,float x,float y,float z)
{
  // get radius
  float dx = robot.ee.pos.x - cx;
  float dy = robot.ee.pos.y - cy;
  float radius = sqrt(dx*dx+dy*dy);

  // find angle of arc (sweep)
  float angle1 = atan3(dy,dx);
  float angle2 = atan3(y-cy,x-cx);
  float theta = angle2 - angle1;

  if(cw>0 && theta<0) angle2 += TWOPI;
  else if(cw<0 && theta>0) angle1 += TWOPI;

  theta = angle2 - angle1;

  // get length of arc
  // float circ=PI*2.0*radius;
  // float len=theta*circ/(PI*2.0);
  // simplifies to
  float len = abs(theta) * radius;

  int i, segments = floor( len / CM_PER_SEGMENT );

  float nx, ny, nz, angle3, scale;

  for(i=0;i<segments;++i)
  {
    // interpolate around the arc
    scale = ((float)i)/((float)segments);

    angle3 = ( theta * scale ) + angle1;
    nx = cx + cos(angle3) * radius;
    ny = cy + sin(angle3) * radius;
    nz = ( z - robot.ee.pos.z ) * scale + robot.ee.pos.z;
    // send it to the planner
    line(nx,ny,nz);
  }
  line(x,y,z);
}


/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
	char string[8]={0};
	int cnt=0;
	time=0;
	counter=0;
	sofar=0;
	pox=0;
	poy=0;
	uartFlag=1;
	for(int i=0;i<5;i++)
		shape[i]={NONE,0,0};
	/*
	shape[0] = {0,0,0};
	shape[1] = {0,0,0};
	shape[2] = {0,0,0};
	shape[3] = {0,0,0};
	shape[4] = {0,0,0};
	*/
    setup_robot();
    start = HAL_GetTick();
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
   MX_GPIO_Init();
   MX_TIM2_Init();
   MX_TIM3_Init();
   MX_TIM4_Init();
   MX_TIM5_Init();
   MX_USART3_UART_Init(); //rx check
   MX_USART6_UART_Init();
  /* USER CODE BEGIN 2 */
   //pwm start
   HAL_TIM_Base_Start(&htim2);
   HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_1);
   HAL_TIM_Base_Start(&htim2);
   HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_2);
   HAL_TIM_Base_Start(&htim3);
   HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1);
   HAL_TIM_Base_Start(&htim4);
   HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_3);
   HAL_TIM_Base_Start(&htim4);
   HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_4);
   HAL_TIM_Base_Start_IT(&htim5); //TIM5 interrupt start
   HAL_UART_Transmit(&huart6, (uint8_t*)TxBuffer, TxBufferSize, 0xFFFF);

   //check community in while{} don't delete
  /*
  HAL_UART_Transmit(&huart3, (uint8_t*)RxBuffer, 8, 10);
  HAL_Delay(500);
  sprintf(string, "%2d \r\n",poy);
  printf(string);
  HAL_Delay(500);
  */
   line(0,-8,10);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
	  if(HAL_UART_Receive(&huart6, (uint8_t*)RxBuffer,8, 50)== HAL_OK && uartFlag)
	  {
		  if(RxBuffer[4]=='0')
		  {
			  //HAL_UART_Transmit(&huart3, (uint8_t*)RxBuffer, 8, 50);
			  RxBuffer[1]=RxBuffer[1]-0x30;
			  pox=((RxBuffer[2]-0x30)*10+(RxBuffer[3]-0x30));
			  poy=((RxBuffer[5]-0x30)*10+(RxBuffer[6]-0x30));
			  pix=CENTERX-pox;
			  piy=poy-CENTERY;
			  switch(RxBuffer[1])
			  {
				  case 0:
					  shape[0].idx=0;
					  shape[0].x=CENTERX-pox;
					  shape[0].y=poy-CENTERY;
					  sprintf(string,"%2d: %2d %2d %2d\r\n", shape[0].idx, shape[0].x , shape[0].y, uartFlag);
					  printf(string);
				  break;
				  case 1:
					  shape[1].idx=1;
					  shape[1].x=CENTERX-pox;
					  shape[1].y=poy-CENTERY;
					  sprintf(string,"%2d: %2d %2d %2d\r\n", shape[1].idx, shape[1].x , shape[1].y, uartFlag);
					  printf(string);
				  break;
				  case 2:
					  shape[2].idx=2;
					  shape[2].x=CENTERX-pox;
					  shape[2].y=poy-CENTERY;
					  sprintf(string,"%2d: %2d %2d %2d\r\n", shape[2].idx, shape[2].x , shape[2].y, uartFlag);
					  printf(string);
				  break;
				  case 3:
					  shape[3].idx=3;
					  shape[3].x=CENTERX-pox;
					  shape[3].y=poy-CENTERY;
					  sprintf(string,"%2d: %2d %2d %2d\r\n", shape[3].idx, shape[3].x , shape[3].y, uartFlag);
					  printf(string);
				  break;
				  case 4:
					  shape[4].idx=4;
					  shape[4].x=CENTERX-pox;
					  shape[4].y=poy-CENTERY;
					  sprintf(string,"%2d: %2d %2d %2d\r\n", shape[4].idx, shape[4].x , shape[4].y, uartFlag);
					  printf(string);
				  break;
			  }
			  conclude();
			  //pix, piy = destination
			  //pix=CENTERX-pox;
			  //piy=poy-CENTERY;
			  //PickUp(8,8);
			  //PickDown(0,0);
		  }

		  if(!uartFlag)
		  {
			  sprintf(string,"%2d: %2d %2d %2d\r\n", shape[0].idx, shape[0].x , shape[0].y, uartFlag);
			  printf(string);
			  sprintf(string,"%2d: %2d %2d %2d\r\n", shape[1].idx, shape[1].x , shape[1].y, uartFlag);
			  printf(string);
			  sprintf(string,"%2d: %2d %2d %2d\r\n", shape[2].idx, shape[2].x , shape[2].y, uartFlag);
			  printf(string);
			  sprintf(string,"%2d: %2d %2d %2d\r\n", shape[3].idx, shape[3].x , shape[3].y, uartFlag);
			  printf(string);
			  sprintf(string,"%2d: %2d %2d %2d\r\n", shape[4].idx, shape[4].x , shape[4].y, uartFlag);
			  printf(string);
		  }

	  }
	  //save and act!!!
	  if(!uartFlag)
	  {
		  PickUp(shape[0].x,shape[0].y);
		  sprintf(string,"%2d: %2d %2d %2d\r\n", shape[0].idx, shape[0].x , shape[0].y, uartFlag);
		  printf(string);
		  PickDown(0,0);
		  PickUp(shape[1].x,shape[1].y);
		  sprintf(string,"%2d: %2d %2d %2d\r\n", shape[1].idx, shape[1].x , shape[1].y, uartFlag);
		  printf(string);
		  PickDown(0,0);
		  PickUp(shape[2].x,shape[2].y);
		  sprintf(string,"%2d: %2d %2d %2d\r\n", shape[2].idx, shape[2].x , shape[2].y, uartFlag);
		  printf(string);
		  PickDown(0,0);
		  PickUp(shape[3].x,shape[3].y);
		  sprintf(string,"%2d: %2d %2d %2d\r\n", shape[3].idx, shape[3].x , shape[3].y, uartFlag);
		  printf(string);
		  PickDown(0,0);
		  PickUp(shape[4].x,shape[4].y);
		  sprintf(string,"%2d: %2d %2d %2d\r\n", shape[4].idx, shape[4].x , shape[4].y, uartFlag);
		  printf(string);
		  PickDown(0,0);
	  }

	  //line(0,-8,10);
	  //PickUp(8,8);
	  //PickDown(0,0);
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}
/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);
  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 96;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV2;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
}
/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 48-1;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 20000-1;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 20000-1;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
    {
      Error_Handler();
    }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */
  HAL_TIM_MspPostInit(&htim2);
}
/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 48-1;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 20000-1;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 20000-1;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */
  HAL_TIM_MspPostInit(&htim3);
}
/**
  * @brief TIM4 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM4_Init(void)
{
  /* USER CODE BEGIN TIM4_Init 0 */

  /* USER CODE END TIM4_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM4_Init 1 */

  /* USER CODE END TIM4_Init 1 */
  htim4.Instance = TIM4;
  htim4.Init.Prescaler = 48-1;
  htim4.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim4.Init.Period = 20000-1;
  htim4.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim4.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim4) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim4, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim4) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim4, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 20000-1;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim4, &sConfigOC, TIM_CHANNEL_3) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim4, &sConfigOC, TIM_CHANNEL_4) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM4_Init 2 */

  /* USER CODE END TIM4_Init 2 */
  HAL_TIM_MspPostInit(&htim4);

}
/**
  * @brief TIM5 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM5_Init(void)
{

  /* USER CODE BEGIN TIM5_Init 0 */

  /* USER CODE END TIM5_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM5_Init 1 */

  /* USER CODE END TIM5_Init 1 */
  htim5.Instance = TIM5;
  htim5.Init.Prescaler = 48000-1;
  htim5.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim5.Init.Period = 0xFFFF;
  htim5.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim5.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim5) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim5, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim5, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM5_Init 2 */

  /* USER CODE END TIM5_Init 2 */
}
/**
  * @brief USART3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART3_UART_Init(void)
{

  /* USER CODE BEGIN USART3_Init 0 */

  /* USER CODE END USART3_Init 0 */

  /* USER CODE BEGIN USART3_Init 1 */

  /* USER CODE END USART3_Init 1 */
  huart3.Instance = USART3;
  huart3.Init.BaudRate = 115200;
  huart3.Init.WordLength = UART_WORDLENGTH_8B;
  huart3.Init.StopBits = UART_STOPBITS_1;
  huart3.Init.Parity = UART_PARITY_NONE;
  huart3.Init.Mode = UART_MODE_TX_RX;
  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART3_Init 2 */

  /* USER CODE END USART3_Init 2 */
}
/**
  * @brief USART6 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART6_UART_Init(void)
{
  /* USER CODE BEGIN USART6_Init 0 */

  /* USER CODE END USART6_Init 0 */

  /* USER CODE BEGIN USART6_Init 1 */

  /* USER CODE END USART6_Init 1 */
  huart6.Instance = USART6;
  huart6.Init.BaudRate = 115200;
  huart6.Init.WordLength = UART_WORDLENGTH_8B;
  huart6.Init.StopBits = UART_STOPBITS_1;
  huart6.Init.Parity = UART_PARITY_NONE;
  huart6.Init.Mode = UART_MODE_TX_RX;
  huart6.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart6.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart6) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART6_Init 2 */

  /* USER CODE END USART6_Init 2 */
}
/*
static void SysTick_Handler(void)
{
  counter++;
}*/
/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOG_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
    HAL_GPIO_WritePin(GPIOG, GPIO_PIN_14, GPIO_PIN_RESET);

  /*Configure GPIO pin : PG9 */
    GPIO_InitStruct.Pin = GPIO_PIN_9;
    GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOG, &GPIO_InitStruct);

   /*Configure GPIO pin : PG14 */
    GPIO_InitStruct.Pin = GPIO_PIN_14;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_PULLUP;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(GPIOG, &GPIO_InitStruct);

   /* EXTI interrupt init*/
    HAL_NVIC_SetPriority(EXTI9_5_IRQn, 0, 0);
    HAL_NVIC_EnableIRQ(EXTI9_5_IRQn);
}
/* USER CODE BEGIN 4 */
//motor control
void Motor1(uint16_t angle)
{
   TIM2->CCR1=(angleZeroPulse+(9*angle));
}
void Motor2(uint16_t angle)
{
   TIM3->CCR1=(angleZeroPulse+(9*angle));
}
void Motor3(uint16_t angle)
{
   TIM4->CCR3=(angleZeroPulse+(9*angle));
}
void Motor4(uint16_t angle)
{
   TIM4->CCR4=(angleZeroPulse+(9*angle));
}
void Spin(uint16_t angle)
{
	TIM2->CCR2=(angleZeroPulse+(9*angle));
}
//interrupt
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	if(htim == &htim5)
	{
		if(counter>=65535)
		{
			time += 65535;
			counter=0;
		}
		else
		{
			counter++;
		}
	}
}
//magnetic
void MagneticOn(void)
{
	HAL_GPIO_WritePin(GPIONucleo, GPIO_PIN_Magnetic, GPIO_PIN_SET );
	HAL_GPIO_WritePin(MAGNETIC, GPIO_PIN_Magnetic, GPIO_PIN_SET );
}
void MagneticOff(void)
{
	HAL_GPIO_WritePin(GPIONucleo, GPIO_PIN_Magnetic, GPIO_PIN_RESET );
	HAL_GPIO_WritePin(MAGNETIC, GPIO_PIN_Magnetic, GPIO_PIN_RESET );
}
//activity
void PickUp(float x, float y)
{
	line(x,y,ZOFFSET1);
	line(x,y,ZOFFSET2);
	MagneticOn();
	line(x,y,ZOFFSET1);
}
void PickDown(float x, float y)
{
	line(x,y,ZOFFSET2);
	MagneticOff();
	line(x,y,ZOFFSET1);
}

void conclude(void)
{
	if(shape[0].idx != NONE && shape[1].idx != NONE && shape[2].idx != NONE && shape[3].idx != NONE && shape[4].idx != NONE)
		uartFlag=0;
	else
		uartFlag=1;
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */

  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
