/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "stdio.h"
#include "math.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

#define TxBufferSize (countof(TxBuffer) - 1)
#define RxBufferSize 0xFF
#define countof(a) (sizeof(a) / sizeof(*(a)))

#ifndef MOTOR_DELTAMOTOR_H_
#define MOTOR_DELTAMOTOR_H_

#define angleZeroPulse 700

#endif

#ifndef MAGNETIC_MAGNETIC_H_
#define MAGNETIC_MAGNETIC_H_

#endif

#define test 50
#define PDeg1  -111.2792
#define PDeg2  -111.2792
#define PDeg3  -111.2792
#define PDeg4  -111.2792

#define lengtha  221/2 //Base half
#define lengthb  148.33 //link connect with Motor
#define lengthc  204.36 //Base?? ?��결된 ?��결링?��
#define lengthd  132/2 //End_Effector half

#define PRINTF 1


/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim3;
TIM_HandleTypeDef htim4;

UART_HandleTypeDef huart1;
UART_HandleTypeDef huart3;
UART_HandleTypeDef huart6;

/* USER CODE BEGIN PV */

uint8_t TxBuffer[] = "\n\rUART Example 1 (Transmission Success !!)\n\r\n\r";
uint8_t RxBuffer[RxBufferSize];
int pox=0;
int poy=0;
typedef struct
{
	double x;
	double y;
	double z;
	double gamma;
	uint16_t deg;

}Motor;

int __io_putchar (int ch)
{
  (void)HAL_UART_Transmit(&huart1, (uint8_t *)&ch, 1, 100);
  return ch;
}

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_TIM3_Init(void);
static void MX_TIM2_Init(void);
static void MX_TIM4_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_USART6_UART_Init(void);
static void MX_USART3_UART_Init(void);
/* USER CODE BEGIN PFP */
void MOTOR1(uint16_t angle);
void MOTOR2(uint16_t angle);
void MOTOR3(uint16_t angle);
void MOTOR4(uint16_t angle);

float Deltakinematic(double posX, double posY, double posZ, double gamma1, double gamma2, double gamma3, double gamma4);
void MotorDeg(double gamma1, double gamma2, double gamma3, double gamma4, double  MotorDeg1, double  MotorDeg2, double  MotorDeg3, double  MotorDeg4);
void MoveXYZ(double x, double y, double z);

void MagneticOn(void);
void MagneticOn(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
#if PRINTF ==1
	#ifdef __cplusplus
		extern "C" int _write(int32_t file, uint8_t *ptr, int32_t len) {
	#else
			int _write(int32_t file, uint8_t *ptr, int32_t len) {
	#endif
		if( HAL_UART_Transmit(&huart1, ptr, len, len) == HAL_OK ) return len;
		else return 0;
	}
#elif PRINTF == 2
	#ifdef __cplusplus
		extern "C" int _write(int32_t file, uint8_t *ptr, int32_t len) {
	#else
		int _write(int32_t file, uint8_t *ptr, int32_t len) {
	#endif
		for(int32_t i = 0; i < len; ++i) { ITM_SendChar(*ptr++); }
		return len;
	}
#endif

Motor M1;
Motor M2;
Motor M3;
Motor M4;

const double PI = 3.141592;

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */
  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM3_Init();
  MX_TIM2_Init();
  MX_TIM4_Init();
  MX_USART1_UART_Init();
  MX_USART6_UART_Init();
  MX_USART3_UART_Init();
  /* USER CODE BEGIN 2 */
  //HAL_UART_Transmit(&huart3, (uint8_t*)TxBuffer, TxBufferSize , 0xFFFF);
  HAL_UART_Transmit(&huart3, (uint8_t*)TxBuffer, TxBufferSize , 0xFFFF);
  HAL_UART_Transmit(&huart6, (uint8_t*)TxBuffer, TxBufferSize, 0xFFFF);
//  HAL_UART_Transmit(&huart3, (uint8_t*)TxBuffer, TxBufferSize, 0xFFFF);

  HAL_TIM_Base_Start(&htim2);
  HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_1);
  HAL_TIM_Base_Start(&htim3);
  HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1);
  HAL_TIM_Base_Start(&htim4);
  HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_3);
  HAL_TIM_Base_Start(&htim4);
  HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_4);


  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {

	  if(HAL_UART_Receive(&huart6, (uint8_t*)RxBuffer,8, 5000)== HAL_OK)
	 	  {
		  	  HAL_UART_Transmit(&huart3, (uint8_t*)RxBuffer, 8, 10);
			  HAL_Delay(500);

			if(RxBuffer[0]<48 &&RxBuffer[0]>57)
			{
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_15, GPIO_PIN_SET);
				pox=RxBuffer[1]*100+RxBuffer[2]*10+RxBuffer[3];
				poy=RxBuffer[4]*100+RxBuffer[5]*10+RxBuffer[6];
			}


	 	  }
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */


	  MoveXYZ(0,10,-50);
	  HAL_Delay(500);
	  MoveXYZ(0,10,-80);
	  HAL_Delay(500);



  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);
  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_BYPASS;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 96;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV4;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 48-1;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 20000-1;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 20000-1;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */
  HAL_TIM_MspPostInit(&htim2);

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 48-1;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 20000-1;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 20000-1;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */
  HAL_TIM_MspPostInit(&htim3);

}

/**
  * @brief TIM4 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM4_Init(void)
{

  /* USER CODE BEGIN TIM4_Init 0 */

  /* USER CODE END TIM4_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM4_Init 1 */

  /* USER CODE END TIM4_Init 1 */
  htim4.Instance = TIM4;
  htim4.Init.Prescaler = 48-1;
  htim4.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim4.Init.Period = 20000-1;
  htim4.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim4.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_PWM_Init(&htim4) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim4, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 20000-1;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim4, &sConfigOC, TIM_CHANNEL_3) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim4, &sConfigOC, TIM_CHANNEL_4) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM4_Init 2 */

  /* USER CODE END TIM4_Init 2 */
  HAL_TIM_MspPostInit(&htim4);

}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief USART3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART3_UART_Init(void)
{

  /* USER CODE BEGIN USART3_Init 0 */

  /* USER CODE END USART3_Init 0 */

  /* USER CODE BEGIN USART3_Init 1 */

  /* USER CODE END USART3_Init 1 */
  huart3.Instance = USART3;
  huart3.Init.BaudRate = 115200;
  huart3.Init.WordLength = UART_WORDLENGTH_8B;
  huart3.Init.StopBits = UART_STOPBITS_1;
  huart3.Init.Parity = UART_PARITY_NONE;
  huart3.Init.Mode = UART_MODE_TX_RX;
  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART3_Init 2 */

  /* USER CODE END USART3_Init 2 */

}

/**
  * @brief USART6 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART6_UART_Init(void)
{

  /* USER CODE BEGIN USART6_Init 0 */

  /* USER CODE END USART6_Init 0 */

  /* USER CODE BEGIN USART6_Init 1 */

  /* USER CODE END USART6_Init 1 */
  huart6.Instance = USART6;
  huart6.Init.BaudRate = 115200;
  huart6.Init.WordLength = UART_WORDLENGTH_8B;
  huart6.Init.StopBits = UART_STOPBITS_1;
  huart6.Init.Parity = UART_PARITY_NONE;
  huart6.Init.Mode = UART_MODE_TX_RX;
  huart6.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart6.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart6) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART6_Init 2 */

  /* USER CODE END USART6_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOG_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_15, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOD, GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3
                          |GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7, GPIO_PIN_RESET);

  /*Configure GPIO pin : PB15 */
  GPIO_InitStruct.Pin = GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : PD0 PD1 PD2 PD3
                           PD4 PD5 PD6 PD7 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3
                          |GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

  /*Configure GPIO pin : PG9 */
  GPIO_InitStruct.Pin = GPIO_PIN_9;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOG, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI9_5_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI9_5_IRQn);

}

/* USER CODE BEGIN 4 */
//motor control
void MOTOR1(uint16_t angle)
{
	TIM2->CCR1=(angleZeroPulse+(9*angle));
}
void MOTOR2(uint16_t angle)
{
	TIM3->CCR1=(angleZeroPulse+(9*angle));
}
void MOTOR3(uint16_t angle)
{
	TIM4->CCR3=(angleZeroPulse+(9*angle));
}
void MOTOR4(uint16_t angle)
{
	TIM4->CCR4=(angleZeroPulse+(9*angle));
}
//Delta inverse kinematics and calculate angles
float Deltakinematic(double posX, double posY, double posZ, double gamma1, double gamma2, double gamma3, double gamma4)
{

  M1.x = posX;
  M1.y = posY;
  M1.z = posZ;

  M2.x =  (cos(90) * (posX)) + (sin(90) * (posY));
  M2.y = -(sin(90) * (posX)) + (cos(90) * (posY));
  M2.z = posZ;

  M3.x =  (cos(180) * (posX)) + (sin(180) * (posY));
  M3.y = -(sin(180) * (posX)) + (cos(180) * (posY));
  M3.z = posZ;

  M4.x =  (cos(270) * (posX)) + (sin(270) * (posY));
  M4.y = -(sin(270) * (posX)) + (cos(270) * (posY));
  M4.z = posZ;

  double length11 = (lengtha - lengthd - M1.y);
  double alpha1 = (360 / (2 * PI)) * (atan2(M1.z, length11));
  double length21 = sqrt(lengthc * lengthc + M1.z * M1.z);
  double length31 = sqrt(lengthc * lengthc - M1.x * M1.x);
  double beta1 = (360 / (2 * PI)) * (acos((length21 * length21 - length31 * length31 - lengthb * lengthb) / (-2 * length31 * lengthb)));
  gamma1 = 180 - alpha1 - beta1;
  M1.gamma=gamma1;

  double length12 = (lengtha - lengthd - M2.y);
  double alpha2 = (360 / (2 * PI)) * (atan2(M2.z, length12));
  double length22 = sqrt(lengthc * lengthc + M2.z * M2.z);
  double length32 = sqrt(lengthc * lengthc - M2.x * M2.x);
  double beta2 = (360 / (2 * PI)) * (acos((length22 * length22 - length32 * length32 - lengthb * lengthb) / (-2 * length32 * lengthb)));
  gamma2 = 180 - alpha2 - beta2;
  M2.gamma=gamma2;

  double length13 = (lengtha - lengthd - M3.y);
  double alpha3 = (360 / (2 * PI)) * (atan2(M3.z, length13));
  double length23 = sqrt(lengthc * lengthc + M3.z * M3.z);
  double length33 = sqrt(lengthc * lengthc - M3.x * M3.x);
  double beta3 = (360 / (2 * PI)) * (acos((length23 * length23 - length33 * length33 - lengthb * lengthb) / (-2 * length33 * lengthb)));
  gamma3 = 180 - alpha3 - beta3;
  M3.gamma=gamma3;

  double length14 = (lengtha - lengthd - M4.y);
  double alpha4 = (360 / (2 * PI)) * (atan2(M4.z, length14));
  double length24 = sqrt(lengthc * lengthc + M4.z * M4.z);
  double length34 = sqrt(lengthc * lengthc - M4.x * M4.x);
  double beta4 = (360 / (2 * PI)) * (acos((length24 * length24 - length34 * length34 - lengthb * lengthb) / (-2 * length34 * lengthb)));
  gamma4 = 180 - alpha4 - beta4;
  M4.gamma=gamma4;

  return 1;
}
void MotorDeg(double gamma1, double gamma2, double gamma3, double gamma4, double  MotorDeg1, double  MotorDeg2, double  MotorDeg3, double  MotorDeg4)
{
  MotorDeg1 = (PDeg1 + gamma1); //기존?�� 모터 값에 ???��?�� 각도�?????? ?��?��?�� ?��?��
  M1.deg=MotorDeg1;
  MotorDeg2 = (PDeg2 + gamma2); //기존?�� 모터 값에 ???��?�� 각도�?????? ?��?��?�� ?��?��
  M2.deg=MotorDeg2;
  MotorDeg3 = (PDeg3 + gamma3); //기존?�� 모터 값에 ???��?�� 각도�?????? ?��?��?�� ?��?��
  M3.deg=MotorDeg3;
  MotorDeg4 = (PDeg4 + gamma4); //기존?�� 모터 값에 ???��?�� 각도�?????? ?��?��?�� ?��?��
  M4.deg=MotorDeg4;
}
void MoveXYZ(double x, double y, double z)
{

	_Bool success = Deltakinematic(x, y, z, M1.gamma, M2.gamma, M3.gamma, M4.gamma);
	if (!success)
		return;
	MotorDeg(M1.gamma, M2.gamma, M3.gamma, M4.gamma,M1.deg,M2.deg,M3.deg,M4.deg);

  MOTOR1(M1.deg);
  MOTOR2(M2.deg);
  MOTOR3(M3.deg);
  MOTOR4(M4.deg);
}
//magnetic
void MagneticOn(void)
{
	HAL_GPIO_WritePin(GPIONucleo, GPIO_PIN_Magnetic, GPIO_PIN_SET );
	HAL_GPIO_WritePin(MAGNETIC, GPIO_PIN_Magnetic, GPIO_PIN_SET );
}
void MagneticOff(void)
{
	HAL_GPIO_WritePin(GPIONucleo, GPIO_PIN_Magnetic, GPIO_PIN_RESET );
	HAL_GPIO_WritePin(MAGNETIC, GPIO_PIN_Magnetic, GPIO_PIN_RESET );
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */

  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
